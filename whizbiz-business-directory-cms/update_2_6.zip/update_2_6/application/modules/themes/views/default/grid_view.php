<?php $CI = get_instance();?>
<div class="clearfix"></div><div class="img-box-4 text-center">
    <?php
    if($posts->num_rows()<=0)
    {
        echo '<div class="alert alert-info">'.lang_key('no_posts').'</div>';
    }
    else
    {
    $i = 0;
    foreach($posts->result() as $post){
        $i++;
        $detail_link = post_detail_url($post);
    ?>
    <div class="col-md-4 col-sm-6">
        <div class="img-box-4-item">
            <!-- Image style one starts -->

            <div class="image-style-one">
                <!-- Image -->
                <a href="<?php echo $detail_link;?>">
                    <img class="img-responsive" alt="<?php echo get_post_data_by_lang($post,'title');?>" src="<?php echo get_featured_photo_by_id($post->featured_img);?>">                        <!-- image hover style for image #1 -->
                </a>

            </div>

            <div class="img-box-4-content">
                <?php if(get_post_meta($post->id,'verified',0) == 1){ ?>
                    <span class="verified-tag" data-toggle="tooltip" data-placement="right" data-original-title="<?php echo lang_key('verified');?>"><i class="fa fa-check"></i></span>
                <?php } ?>


                <?php if($post->featured == 1){ ?>
                    <span class="hot-tag" data-toggle="tooltip" data-placement="left" data-original-title="<?php echo lang_key('featured');?>"><i class="fa fa-bookmark"></i></span>
                <?php } ?>
                <?php
                $class = "fa ";
                
                    $class .= $CI->post_model->get_category_icon($post->category);
                
                if($i%4 == 1)
                    $class .= " bg-lblue";
                else if($i%4 == 2)
                    $class .= " bg-green";
                else if($i%4 == 3)
                    $class .= " bg-orange";
                else
                    $class .= " bg-red";
                ?>
                <a class="b-tooltip" title="<?php echo get_category_titles_by_id_array($post->category); ?>" href="javascript:void(0);"><i class="category-fa-icon <?php echo $class;?>"></i></a>
                <div class="cat-title"><?php echo get_category_titles_by_id_array($post->category,TRUE); ?></div>
                <h4 class="item-title"><a href="<?php echo $detail_link;?>"><?php echo format_long_text(get_post_data_by_lang($post,'title'));?></a></h4><!-- updated onversion 1.6 -->
                <div class="bor bg-red"></div>
                <div class="row">

                    <div class="col-xs-12 col-sm-12 col-md-12 info-dta info-price">
                        <?php $average_rating = $post->rating; ?>
                        <?php $half_star_position = check_half_star_position($average_rating); ?>
                        <a href="<?php echo $detail_link;?>#review">
                        <?php echo get_review_with_half_stars($average_rating,$half_star_position);?>
                        </a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 info-dta"><a href="<?php echo site_url('location-posts/'.$post->city.'/city/'.dbc_url_title(get_location_name_by_id($post->city)));?>"><?php echo get_location_name_by_id($post->city);?></a></div>
                </div>
                <div class="row">
                    <?php if(get_post_meta($post->id,'hide_my_phone','')!=1){?>
                    <div class="col-xs-12 col-sm-12 col-md-12 info-dta info-phone"><i class="fa fa-phone"></i> &nbsp;<?php echo $post->phone_no; ?></div>
                    <?php }else{?>
                    <div class="col-xs-12 col-sm-12 col-md-12 info-dta info-phone"><a href="<?php echo $detail_link;?>#contact" class="btn"><i class="fa fa fa-envelope"></i> <?php echo lang_key('contact');?></a></div>
                    <?php }?>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>                

    <?php 
        }
    }
    ?>
</div>
<div class="clearfix"></div>
<?php echo (isset($pages))?'<ul class="pagination">'.$pages.'</ul>':'';?>